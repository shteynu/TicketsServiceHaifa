package application.entities;

public class User extends Person {

	private String nameUser;
	private String surnameUser;
	private String companyUser;
	private String streetUser;
	private String houseUser;
	private String addInfoUser;
	private int postcodeUser;
	private String cityUser;
	private String countryUser;
	private String emailUser;
	private String phoneNumberUser;
	private String additionalPhonenumber;
}
