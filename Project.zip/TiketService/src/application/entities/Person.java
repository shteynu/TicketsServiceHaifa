package application.entities;

public class Person {

	private int ID;
	private String login;
	private String password;
	private String rol;
}
