package application.entities;

public class Administrator extends Person {

	
	
}
