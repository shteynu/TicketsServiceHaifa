package application.model;

interface I_User extends I_Person {

	
}
